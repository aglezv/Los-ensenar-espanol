# LOS – Aprende español como un bebé

Este proyecto está basado en Next.js y Tailwind CSS.

## Ejecutar localmente
```bash
npm install
npm run dev
```